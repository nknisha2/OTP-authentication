

export const getAllPosts = async (req, res) => {
    try {

        console.log('getAllPosts')

    }
    catch (error) {

    }
}


// these functions will only be accessed by authenticated users
